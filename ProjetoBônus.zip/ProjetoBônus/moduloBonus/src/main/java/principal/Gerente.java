
package principal;


public class Gerente extends Funcionario {
    public Gerente(String nome, int id, double salario, int departamentoId) {
        super(nome, id, salario, "Gerente", departamentoId);
    }
}
