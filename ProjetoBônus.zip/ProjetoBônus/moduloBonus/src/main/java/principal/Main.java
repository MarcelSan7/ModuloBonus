package principal;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Criar lista de departamentos
        List<Departamento> departamentos = new ArrayList<>();
        departamentos.add(new Departamento(1, 50000));
        departamentos.add(new Departamento(2, 76000));
        departamentos.add(new Departamento(3, 76000));
        departamentos.add(new Departamento(4, 79000));
        

        // Criar lista encadeada de funcionários
        Funcionario head = new Vendedor("Joao", 1, 120000, 2);
        Funcionario f2 = new Gerente("Paulo", 2, 160000, 2);
        Funcionario f3 = new Vendedor("Julia", 3, 140000, 2);
        Funcionario f4 = new Vendedor("Plinio", 4, 5000, 3);
        Funcionario f5 = new Gerente("Aline", 5, 130000, 4);
        Funcionario f6 = new Vendedor("Carlos", 6, 1200, 4);

        // Encadear os funcionários
        head.setProximo(f2);
        f2.setProximo(f3);
        f3.setProximo(f4);
        f4.setProximo(f5);
        f5.setProximo(f6);

        // Calcular bônus
        Bonus bonus = new Bonus();
        try {
            int resultado = bonus.calcularBonus(head, departamentos);
            // Exibir salários atualizados
            Funcionario atual = head;
            while (atual != null) {
                System.out.println("ID: " + atual.getNome()+", " + atual.getId() + ", Salario: " + atual.getSalario());
                atual = atual.getProximo();
            }
            System.out.println("Resultado: " + resultado);
        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
            System.exit(2); // Retornar código de erro 2
        }
    }
}
