
package principal;

public class Funcionario {
    public String nome;
    private int id;
    private double salario;
    private String cargo;
    private int departamentoId;
    private Funcionario proximo;

    public Funcionario(String nome, int id, double salario, String cargo, int departamentoId) {
        this.nome = nome;
        this.id = id;
        this.salario = salario;
        this.cargo = cargo;
        this.departamentoId = departamentoId;
        this.proximo = null;
    }

   
    public String getNome(){
        return nome;
    }
    public int getId(){
        return id;
    }
    public double getSalario(){
        return salario;
    }
    public String getCargo(){
        return cargo;
    }
    public int getDepartamentoId(){
        return departamentoId;
    }
    public Funcionario getProximo(){ 
        return proximo; 
    }
    
    
    public void setProximo(Funcionario proximo){
        this.proximo = proximo;
    }
    public void setSalario(double salario){
        this.salario = salario;
    }
}
