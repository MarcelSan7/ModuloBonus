package principal;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Bonus {
    public int calcularBonus(Funcionario head, List<Departamento> departamentos) {
        // Verificar se o funcionário head ou a lista de departamentos são nulos ou vazios
        if (head == null || departamentos == null || departamentos.isEmpty()) {
            throw new IllegalArgumentException("Código 1: Tabelas de entrada vazias.");
        }

        // Encontrar o maior valor de vendas entre os departamentos
        double maiorVenda = departamentos.stream()
                                         .mapToDouble(Departamento::getValorVendas)
                                         .max()
                                         .orElse(0);

        // Encontrar todos os departamentos com o maior valor de vendas
        List<Integer> departamentosTopIds = departamentos.stream()
                                                         .filter(d -> d.getValorVendas() == maiorVenda)
                                                         .map(Departamento::getId)
                                                         .collect(Collectors.toList());

        if (departamentosTopIds.isEmpty()) {
            throw new IllegalArgumentException("Código 2: Nenhum departamento encontrado.");
        }

        Funcionario atual = head;
        boolean funcionarioElegivel = false;

        // Iterar sobre a lista de funcionários vinculados
        while (atual != null) {
            // Verificar se o funcionário pertence a um dos departamentos com a maior venda
            if (departamentosTopIds.contains(atual.getDepartamentoId())) {
                funcionarioElegivel = true;
                
                // Calcular o bônus de acordo com as regras
                double bonus = (atual.getSalario() >= 150000 || "Gerente".equals(atual.getCargo())) ? 1000 : 2000;
                atual.setSalario(atual.getSalario() + bonus);
            }
            atual = atual.getProximo();
        }

        // Se nenhum funcionário for elegível, lançar exceção com código de erro 2
        if (!funcionarioElegivel) {
            throw new IllegalArgumentException("Código 2: Nenhum funcionário elegível.");
        }

        // Retornar 0 para indicar sucesso
        return 0;
    }
}
