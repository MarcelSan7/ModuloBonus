
package principal;

public class Departamento {
    private int id;
    private double valorVendas;

    public Departamento(int id, double valorVendas) {
        this.id = id;
        this.valorVendas = valorVendas;
    }

    // Getters e setters
    public int getId() { return id; }
    public double getValorVendas() { return valorVendas; }
}
