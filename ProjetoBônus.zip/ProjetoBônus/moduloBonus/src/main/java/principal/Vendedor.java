
package principal;

public class Vendedor extends Funcionario {
    public Vendedor(String nome, int id, double salario, int departamentoId) {
        super(nome, id, salario, "Vendedor", departamentoId);
    }
}
